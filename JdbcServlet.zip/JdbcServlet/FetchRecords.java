import java.io.*;  
import java.sql.*;
import javax.servlet.*;  
import javax.servlet.http.*;  

  public class FetchRecords extends HttpServlet
{  
protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
{  
res.setContentType("text/html");  

PrintWriter out=res.getWriter();  

try{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();  
		
ResultSet rs=stmt.executeQuery("select * from stdinfo");  

out.println("<table border='1'>");
out.println("<tr><th>Red Id</th><th>Name</th><th>Email</th></tr>");
    while(rs.next()) {
        out.println("<tr><td>" + rs.getString("rno") + "</td><td>" + rs.getString("Name") + "</td><td>" + rs.getString("email") + "</td></tr>");
    }
    out.println("</table>");

con.close();  
}
catch(Exception e)
{
out.print(e);
} 
}  } 
