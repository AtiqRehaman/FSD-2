import java.io.*;  
import java.sql.*;
import javax.servlet.*;  
import javax.servlet.http.*;  

  public class FetchRecords extends HttpServlet
{  
protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
{  
res.setContentType("text/html");  

PrintWriter out=res.getWriter();  

try{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
Statement stmt=con.createStatement();  
		
ResultSet rs=stmt.executeQuery("select * from MsUsers");  

out.println("<table border='1'>");
out.println("<tr><th>UserID</th><th>UserName</th></tr>");
    while(rs.next()) {
        out.println("<tr><td>" + rs.getString("USER_ID") + "</td><td>" + rs.getString("USER_NAME") + "</td></tr>");
    }
    out.println("</table>");

con.close();  
}
catch(Exception e)
{
out.print(e);
} 
}  } 
