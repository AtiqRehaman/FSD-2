import java.io.*;  
import java.sql.*;
import javax.servlet.*;  
import javax.servlet.http.*;  

  public class DbCon extends HttpServlet
{  
protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
{  
res.setContentType("text/html");  

PrintWriter out=res.getWriter();  

try{
Class.forName("oracle.jdbc.driver.OracleDriver");
Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","manager");
if (con != null) 
 {
out.print("Oracle Database Connected");
} 
con.close();  
}
catch(Exception e)
{
out.print(e);
} 
}  } 
