import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Validate extends HttpServlet
{
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        String userName = req.getParameter("un");
        String pwd = req.getParameter("pwd");
        if(pwd.equals("admin"))
        {
            out.print("<center><h1>Login Successful..</h1?<center>");
            out.print("<center><h1>Welcome to Servlet Application</h1?<center>");
        }
        else
            out.print("<center><h1>Invalid Password.</h1?<center>");
    }
}