import java.io.*;  
import java.sql.*;
import javax.servlet.*;  
import javax.servlet.http.*;  

public class studentRegister extends HttpServlet
{  
  protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
  {  
    res.setContentType("text/html");  

    PrintWriter out = res.getWriter();  

    try
    {
      String rol = req.getParameter("rn");
      String name = req.getParameter("sn");
      String email = req.getParameter("mail");
      String pwd = req.getParameter("pwd");


      out.print(rol);
      out.print(name);
      out.print(email);
      out.print(pwd);

      Class.forName("oracle.jdbc.driver.OracleDriver");
      Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");
      // Statement stmt = con.createStatement();  
      // String sql = "Insert into stdinfo values ('"+rol+"','"+name+"','"+email+"','"+pwd+"')";
      //stmt.executeUpdate(sql);

      PreparedStatement pst = con.prepareStatement("insert into stdinfo values (?,?,?,?)");

      pst.setString(1,rol);
      pst.setString(2,name);
      pst.setString(3,email);
      pst.setString(4,pwd);

      out.println("<h1>New data inserted!</h1>");
      con.close();  
    }
    catch(Exception e)
    {
      out.print(e);
    } 
  }  
} 
