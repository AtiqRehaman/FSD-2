import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FetchRec extends HttpServlet
{
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
    {
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","manager");


            String sql="select * from msusers";

            Statement stmt = con.createStatement();

            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next())
            {
            out.print("User_id:"+rs.getString(1));
            out.print("User_name:"+rs.getString(2));
            out.print("password:"+rs.getString(3));
            out.print("Role:"+rs.getString(4));
            }
            con.close();
        }
        catch(Exception e)
        {
            out.print(e);
        }
            //out.print("<center><h1>Invalid Password.</h1?<center>");
    }
}